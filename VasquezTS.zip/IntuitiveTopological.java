import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class IntuitiveTopological implements TopologicalSort 
{
    private BetterDiGraph graph;

    public IntuitiveTopological(BetterDiGraph graph) {
        this.graph = graph;
    }

	 /**
     * Returns an iterable object containing a topological sort.
     * @return a topological sort.
     */
    public Iterable<Integer> order()
    {
    	
    	Queue<Integer> topo = new LinkedList<>();
    	//Get Graph
    	//Enter Loop
    
        for (Integer vertex: graph.vertices())
        {
	        //find 0's of graph
	        Queue<Integer> zeroes = new LinkedList<Integer>();
	        if(graph.getIndegree(vertex)==0)
	        	zeroes.add(vertex);
	        while(zeroes.size()>0)
	        {
	       
	        	if(zeroes.size()>0)
	        	{
	        		topo.add(zeroes.remove()); 
	        	}
	        	graph.removeVertex(vertex);
	        }
        }
        return null;
    }
    
    /**
     * Returns true if the graph being sorted is a DAG, false otherwise.
     * @return is graph a DAG
     */
    public boolean isDAG()
    {
    	return (order()!=null);
    }
    
}
