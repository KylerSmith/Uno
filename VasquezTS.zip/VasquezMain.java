import java.io.*;
import java.util.HashMap;
import java.util.Queue;
public class VasquezMain 
{
    public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException
    {
        
        HashMap dictionary = new HashMap<>();
        BetterDiGraph graph = new BetterDiGraph(0);


//        BufferedReader indexReader1 = new BufferedReader(new InputStreamReader(new FileInputStream(new File("data-kanji.txt")), "UTF8"));
//        while (true ) {
//            try {
//                String input = indexReader1.readLine();
//                if (input == null || input.length() == 0) {
//                    break;
//                }
//                String[] fields = input.split("\t");
//                Integer src = Integer.valueOf(fields[0]);
//                String symbol = fields[1];
//                dictionary.put(src, symbol);
//            } catch (IOException e) {
//                break;
//            }
//        }
        BufferedReader indexReader2 = new BufferedReader(new InputStreamReader(new FileInputStream(new File("data-components.txt")), "UTF8"));
        while (true )
        {
            try
            {
                String input = indexReader2.readLine();
                if (input==null || input.length()==0)
                {
                    break;
                }
                String[] fields = input.split("\t");
                Integer src = Integer.valueOf(fields[0]);
                Integer dest = Integer.valueOf(fields[1]);
                if (graph.getAdj(src) == null)
                {
                    graph.addVertex(src);
                }
                if (graph.getAdj(dest) == null)
                {
                    graph.addVertex(dest);
                }
                graph.addEdge(src, dest);
            } catch (IOException e)
            {
                break;
            }
        }
        IntuitiveTopological topoSort = new IntuitiveTopological(graph);
        Iterable<Integer> output =topoSort.order();
        String outputStr = "";
        for(Integer item: output)
        {
        	outputStr+=(item+" ");
        }
        System.out.println(">> TopoSort: " + outputStr);
        
    }
}


