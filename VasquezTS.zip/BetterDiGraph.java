import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.Stack;
import java.util.LinkedList;
import java.util.HashMap;

public class BetterDiGraph implements EditableDiGraph
{
	private Integer vertexCount; //number of vertices
	private Integer edgeCount; //number of edges
	private HashMap<Integer,LinkedList<Integer>> adj = new HashMap<>();
	
	public BetterDiGraph(int size)
	{
		this.vertexCount = size;
		this.edgeCount =0;
		for (Integer v=0; v<vertexCount; v++)
			adj.put(v, new LinkedList<Integer>()); 
	}

	public int V() {return vertexCount;}
	public int E() {return edgeCount;}
	
	// v= start // w= destination 
    public void addEdge(int v, int w)
    {
    	if(adj.get(v)==null)
    	{
    		addVertex(v);
    	}
    	adj.get(v).add(w);
    	edgeCount++;
    }
    
    //make a new array with added vertex
    public void addVertex(int v)
    {
    	adj.put(v, new LinkedList<>());
    	vertexCount++;
    }
    
    //return an iterable of adjacencies
    public Iterable<Integer> getAdj(int v)
    {
    	Queue<Integer> queue = new LinkedList<>();
    	if(adj.get(v)==null)
    	{
    		return queue;
    	}
    	for(Integer item:adj.get(v))
    	{
    		if(item==null)
    		{
    			return queue;
    		}
    		queue.add(item);
    	}
    	return queue;
    }
    
    public int getEdgeCount()
    {
    	return edgeCount;
    }
    
    //how many destinations = v?
    public int getIndegree(int v) throws NoSuchElementException
    {
    	int count=0;
    	for(int i=0;i<vertexCount;i++)
    	{
	    	Queue<Integer> node = new LinkedList<>();
	    	
	    	node=(Queue<Integer>) getAdj(i);
	    	if (node.size()==0)
	    	{
	    		return 0;
	    	}
	    	while (node.size() != 0)
	    	{
	    		if (v==node.remove())
	    		{
	    			count++;
	    		}
	    	}
    	}	
    	return count;
    }
 
    public int getVertexCount()
    {
    	return vertexCount;
    }
    
    public void removeEdge(int v, int w)
    {
    	adj.get(v).remove(w);
    	edgeCount--;
    }
    
    public void removeVertex(int v)
    {
    	adj.remove(v);
    }

    // return queue of vertices
    public Iterable<Integer> vertices()
    {
    	Queue<Integer> queue = new LinkedList<>();
    	for(Integer item:adj.keySet())
    		queue.add(item);
    	return queue;
    }
    
    
    }

