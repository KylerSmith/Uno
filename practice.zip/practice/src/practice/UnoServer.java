package practice;
import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

public class UnoServer extends JFrame {

  // Text area for displaying contents
  private JTextArea jta = new JTextArea();

  public static void main(String[] args) {
    new UnoServer();
  }

  public UnoServer() {

    // Place text area on the frame
    setLayout(new BorderLayout());
    add(new JScrollPane(jta), BorderLayout.CENTER);
    setTitle("MultiThreadServer");
    setSize(500, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true); // It is necessary to show the frame here!

    try {

      // Create a server socket
      ServerSocket serverSocket = new ServerSocket(8000);
      jta.append("MultiThreadServer started at " + new Date() + '\n');

      // Number a client
      int clientNo = 1;

      while (true) {

        // Listen for a new connection request
        Socket socket = serverSocket.accept();

        // Display the client number
        jta.append("Starting thread for client " + clientNo + " at " + new Date() + '\n');

        // Find the client's host name, and IP address
        InetAddress inetAddress = socket.getInetAddress();
        jta.append("Client " + clientNo + "'s host name is " + inetAddress.getHostName() + "\n");
        jta.append("Client " + clientNo + "'s IP Address is " + inetAddress.getHostAddress() + "\n");

        // Create a new thread for the connection
        HandleAClient task = new HandleAClient(socket);

        // Start the new thread
        new Thread(task).start();

        // Increment clientNo
        clientNo++;
      }
    }
    catch(IOException ex) {
      System.err.println(ex);
    }
  }

  // Inner class
  // Define the thread class for handling new connection
  class HandleAClient implements Runnable {

    private Socket socket; // A connected socket

    /** Construct a thread */
    public HandleAClient(Socket socket) {
      this.socket = socket;
    }

    /** Run a thread */
    public void run() {
      try {
 
        // Create data input and output streams
        DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

        // Continuously serve the client
        while (true) {
        	// code that the server constantly runs. =================================

        	
        	
        	
        	
        	//=========================================================================
        	
        }
      }
      catch(IOException e) {
        System.err.println(e);
      }
    }
  }
  
//  
////  class GameLogic {
////	
////	// constructor for gameLogic class
////  	public GameLogic() {
////  		
////
////		/* make the draw and discard decks (as stacks) */
////		Unodeck drawDeck = new Unodeck(); 
////		Unodeck discardDeck = new Unodeck();
////		/* fill the draw deck and shuffle it */
////		drawDeck.fillDeck();
////		drawDeck.shuffleDeck();
////
////		/* create the 2 players */
////		Player player1 = new Player(drawDeck);
////		Player player2 = new Player(drawDeck);
////		
////		/* display the players hands */
////		player1.displayHand();	
////		player2.displayHand();
////		
////		
////		/* Flip the first card from the draw deck to discard deck, if it is an action card */
////		discardDeck.pushCard(drawDeck.popCard());
////		
////		/* while there is no winner */
////		while (!isWinner(player1, player2)) {
////			
////			//playCard(Player pPlayer1, Player pPlayer2, Unodeck pDrawDeck, Unodeck pDiscardDeck);
////			
////		}
////		
////		//drawDeck.displayDeck();
////		//discardDeck.pushCard(drawDeck.popCard());	
////		discardDeck.displayDeck();
////	}
////  	
////	public boolean isWinner(Player p1, Player p2) {
////		boolean returnValue = false; // return
////		
////		if (p1.handSize == 0 || p2.handSize == 0) {
////			returnValue = true;
////		}
////		
////		return false;
////	}
////  		
////  	}
////  	
////  	
////  	
////  	
////  	
////	  
////	  
////  }
////  
//  
  
  
  
  
  
  
  
  
  
}